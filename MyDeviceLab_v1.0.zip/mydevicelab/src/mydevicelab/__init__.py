"""MyDeviceLab - local-first GTK4 front-end for the Android Emulator."""

__version__ = "1.0.0"
APP_ID = "io.github.gussalazar.MyDeviceLab"
APP_NAME = "MyDeviceLab"
